
document.addEventListener("click", () => {
  const audio = document.getElementById("bg-music");
  if (audio) {
    audio.play().catch(() => {});
  }
});
